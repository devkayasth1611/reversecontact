import React from 'react'
import Index from './components'
import './App.css'

function App() {

  return (
    <>
      <Index />
    </>
  )
}

export default App
