import React from "react";
import { DownOutlined } from "@ant-design/icons";
import "../App.css";

function Index() {
  return (
    <div className="page-container">
      {/* Header Section */}
      <header className="header">
        <div className="logo">Reverse Contact</div>
        <ul className="nav-links">
          <li className="dropdown-container">
            <a href="#">
              Product <DownOutlined />
            </a>
            <div className="dropdown">
              <a href="#">Mobile Enrichment</a>
              <a href="#">LinkedIn contact verification</a>
            </div>
          </li>
          <li className="dropdown-container">
            <a href="#">
              Resources <DownOutlined />
            </a>
            <div className="dropdown">
              <a href="#">Web Development</a>
              <a href="#">App Development</a>
              <a href="#">SEO</a>
            </div>
          </li>
          <li>
            <a href="#">About</a>
          </li>
          <li>
            <a href="#">Contact</a>
          </li>
        </ul>
        <div className="auth-buttons">
          <button className="auth-btn login">Login</button>
          <button className="auth-btn signup">Sign Up</button>
        </div>
      </header>

      {/* Main Content */}
      <main className="main-content">
        {/* Example Content */}
        <section className="hero">
          <h1>Welcome to Reverse Contact</h1>
          <p>Turn emails into actionable LinkedIn data!</p>
        </section>
      </main>
      {/* <!-- Footer --> */}
      <footer>
        <div className="footer-container">
          <div className="footer-section">
            <h3>Reverse Contact</h3>
            <p>Data enrichment for Business</p>
            <div className="footer-icons">
              <img src="https://via.placeholder.com/40" alt="GDPR" />
              <img src="https://via.placeholder.com/40" alt="CCPA" />
              <img src="https://via.placeholder.com/40" alt="AICPA SOC" />
            </div>
            <div className="social-icons">
              <a href="#">
                <img src="../public/LinkedIn.png" alt="LinkedIn" />
              </a>
              <a href="#">
                <img src="../public/youtube.png" alt="YouTube" />
              </a>
            </div>
          </div>
          <div className="footer-section">
            <h4>Menu</h4>
            <ul>
              <li>
                <a href="#">Home</a>
              </li>
              <li>
                <a href="#">Pricing</a>
              </li>
              <li>
                <a href="#">Login</a>
              </li>
              <li>
                <a href="#">Sign up</a>
              </li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Product</h4>
            <ul>
              <li>
                <a href="#">Reverse Email Lookup</a>
              </li>
              <li>
                <a href="#">Email Enrichment</a>
              </li>
              <li>
                <a href="#">Email Verification</a>
              </li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Popular Resources</h4>
            <ul>
              <li>
                <a href="#">Clearbit Alternatives</a>
              </li>
              <li>
                <a href="#">How to find LinkedIn by email?</a>
              </li>
            </ul>
          </div>
          <div className="footer-section">
            <h4>Resources</h4>
            <ul>
              <li>
                <a href="#">Case Studies</a>
              </li>
              <li>
                <a href="#">Blog</a>
              </li>
              <li>
                <a href="#">Integrations</a>
              </li>
              <li>
                <a href="#">Help Center</a>
              </li>
              <li>
                <a href="#">API Documentation</a>
              </li>
              <li>
                <a href="#">API Status</a>
              </li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <p>Copyright © 2024 | All Rights Reserved. Powered by Visum.</p>
          <div className="footer-links">
            <a href="#">Terms</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Security Policy</a>
            <a href="#">Cookies Policy</a>
            <a href="#">Data Processing Agreement</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default Index;
